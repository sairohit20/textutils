# TextUtils
A tool for analyzing text data in Django backend

It is a simple django project or website in which we can Analyze text.

<h1>What Can We do from Textutils ?</h1>
1)Remove Punctuations<br>
2)UPPERCASE<br>
3)New Line Remove<br>
4)Extra Spaces Remover<br>
5)Numbers Remover

<h1>Requirments</h1>
python3<br>
django<br>
